import unittest, os, sys, time
from altgraph import Graph, GraphAlgo, Dot

class GraphLib2Test(unittest.TestCase):
	
	def test_altgraph(self):

		# these are the edges
		edges = [ (1,2), (2,4), (1,3), (2,4), (3,4), (4,5), (6,5), (6,14), (14,15), (6, 15),
		(5,7), (7, 8), (7,13), (12,8), (8,13), (11,12), (11,9), (13,11), (9,13), (13,10) ]

		store = {}
		g = Graph.Graph()
		for head, tail in edges:
			store[head] = store[tail] = None
			g.add_edge(head, tail)
		
		# check the parameters				
		self.assertEqual(g.number_of_nodes(), len(store) )
		self.assertEqual(g.number_of_edges(), len(edges) )

		
		# do a forward bfs
		print g.forw_bfs(1)

		# diplay the hops and hop numbers between nodes
		print g.get_hops(1, 8)
		
		#print g.clust_coef(6)

		print GraphAlgo.shortest_path(g, 1, 12)
		
		#print GraphAlgo.dijkstra(g, 1, 12)

		# enable these if you have graphviz

		# create a dot representation of the graph
		#dot = GraphDot.Dot(g)
		
		# display the graph
		#dot.display()
		
		# save the dot representation into the mydot.dot file
		#dot.save_dot(file_name='mydot.dot')

		# save dot file as gif image into the graph.gif file
		#dot.save_img(file_name='graph', file_type='gif')

if __name__ == '__main__':
	unittest.main()
